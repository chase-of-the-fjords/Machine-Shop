(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 4144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1865);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6327);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5150)), "C:\\Users\\chase\\OneDrive\\Desktop\\Coding\\Web Development\\Origin Golf\\Origin Golf Machine Shop\\machine-shop\\app\\page.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7414)), "C:\\Users\\chase\\OneDrive\\Desktop\\Coding\\Web Development\\Origin Golf\\Origin Golf Machine Shop\\machine-shop\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\chase\\OneDrive\\Desktop\\Coding\\Web Development\\Origin Golf\\Origin Golf Machine Shop\\machine-shop\\app\\page.js"];
    
    const originalPathname = "/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 7407:
/***/ (() => {



/***/ }),

/***/ 5454:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7734, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 8709, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2698, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7833, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9150, 23))

/***/ }),

/***/ 6961:
/***/ (() => {



/***/ }),

/***/ 9991:
/***/ ((module) => {

// Exports
module.exports = {
	"menu": "App_menu__0uy3J",
	"shop": "App_shop__Qmb6z"
};


/***/ }),

/***/ 6144:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "Building_header__Q5Rc0",
	"building": "Building_building__lC_a1",
	"buildingContainer": "Building_buildingContainer__1CSet"
};


/***/ }),

/***/ 2894:
/***/ ((module) => {

// Exports
module.exports = {
	"machine": "Machine_machine__FMtxi"
};


/***/ }),

/***/ 7414:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout),
/* harmony export */   metadata: () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2412);
/* harmony import */ var next_font_google_target_css_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2817);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_globals_css__WEBPACK_IMPORTED_MODULE_1__);



const metadata = {
    title: "Create Next App",
    description: "Generated by create next app"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
            className: (next_font_google_target_css_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2___default().className),
            children: children
        })
    });
}


/***/ }),

/***/ 5150:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
;// CONCATENATED MODULE: ./app/data/machines.json
const machines_namespaceObject = JSON.parse('{"O":[{"name":"Suite 2","code":"s2","width":4,"height":6,"machines":[{"name":"Saw","code":"SAW","width":1,"height":1.5,"x":2,"y":1},{"name":"Okuma B","code":"OB","width":1,"height":2,"x":3,"y":1},{"name":"Okuma A","code":"OA","width":1,"height":2,"x":4,"y":1},{"name":"APC","code":"APC","width":1,"height":1,"x":1,"y":3},{"name":"Haas 8","code":"H8","width":1,"height":1,"x":1,"y":4},{"name":"Haas 7","code":"H7","width":1,"height":1,"x":1,"y":5},{"name":"Haas 6","code":"H6","width":1,"height":1,"x":1,"y":6},{"name":"Brother C","code":"BC","width":1,"height":1,"x":3,"y":4},{"name":"Brother B","code":"BB","width":1,"height":1,"x":3,"y":5},{"name":"Brother A","code":"BA","width":1,"height":1,"x":3,"y":6},{"name":"Mini B","code":"mb","width":1,"height":1,"x":4,"y":4.5},{"name":"Mini A","code":"ma","width":1,"height":1,"x":4,"y":5.5}]},{"name":"Suite 3","code":"s3","width":4,"height":5,"machines":[{"name":"Haas 3","code":"H3","width":1,"height":1,"x":2,"y":1},{"name":"Haas 4","code":"H4","width":1,"height":1,"x":3,"y":1},{"name":"Haas 5","code":"H5","width":1,"height":1,"x":4,"y":1},{"name":"Haas 2","code":"H2","width":1,"height":1,"x":2,"y":2},{"name":"Haas 1","code":"H1","width":1,"height":1,"x":2,"y":3},{"name":"Okuma C","code":"OC","width":1,"height":2,"x":3,"y":2.5},{"name":"Okuma D","code":"OD","width":1,"height":2,"x":4,"y":2.5}]}]}');
// EXTERNAL MODULE: ./app/modules/Machine.module.css
var Machine_module = __webpack_require__(2894);
var Machine_module_default = /*#__PURE__*/__webpack_require__.n(Machine_module);
;// CONCATENATED MODULE: ./app/modules/Machine.js


function Machine({ data }) {
    let width = data.width * 120 - 5;
    let height = data.height * 120 - 5;
    let top = 5 + (data.y - 1) * 120;
    let left = 5 + (data.x - 1) * 120;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: (Machine_module_default()).machine,
                style: {
                    width: `${width}px`,
                    height: `${height}px`,
                    top: `${top}px`,
                    left: `${left}px`
                },
                children: data.name
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("br", {})
        ]
    });
}

// EXTERNAL MODULE: ./app/modules/Building.module.css
var Building_module = __webpack_require__(6144);
var Building_module_default = /*#__PURE__*/__webpack_require__.n(Building_module);
;// CONCATENATED MODULE: ./app/modules/Building.js



// Individual Building
function Building({ data }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Building_module_default()).buildingContainer,
        style: {
            width: `${data.width * 120 + 100}px`
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: (Building_module_default()).header,
                children: data.name
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Building_module_default()).building,
                style: {
                    width: `${data.width * 120}px`,
                    height: `${data.height * 120}px`
                },
                children: data.machines.map((machine)=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx(Machine, {
                        data: machine
                    }, machine.code);
                })
            })
        ]
    });
}

// EXTERNAL MODULE: ./app/modules/App.module.css
var App_module = __webpack_require__(9991);
var App_module_default = /*#__PURE__*/__webpack_require__.n(App_module);
;// CONCATENATED MODULE: ./app/page.js





let shops = machines_namespaceObject.O;
// The full main page
function App() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Menu, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Shop, {})
        ]
    });
}
// Menu Bar
function Menu() {
    return /*#__PURE__*/ jsx_runtime_.jsx("h1", {
        className: (App_module_default()).menu,
        style: {},
        children: "Origin Golf Machine Shop"
    });
}
function Shop() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (App_module_default()).shop,
        children: shops.map((shop)=>{
            return /*#__PURE__*/ jsx_runtime_.jsx(Building, {
                data: shop
            }, shop.code);
        })
    });
}


/***/ }),

/***/ 3174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3785);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 2817:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [697,8], () => (__webpack_exec__(4144)));
module.exports = __webpack_exports__;

})();